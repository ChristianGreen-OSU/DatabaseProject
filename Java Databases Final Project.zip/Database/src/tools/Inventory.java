package tools;

import java.util.ArrayList;

public class Inventory {

    private ArrayList<Media> inventory; // creates a list containing "media"

    /**
     * No-argument constructor - creates an empty inventory
     *
     * @postcond inventory object is empty
     */
    public Inventory() {
        this.inventory = new ArrayList<Media>(); // initializes the list
    }

    public Media getMediaByKey(int key) {
        int f = -1;
        for (int i = 0; i < this.inventory.size(); i++) {
            if (key == this.inventory.get(i).getItemNo()) {
                f = i;
            }
        }
        return this.inventory.get(f);
    }

    public Media getMediaByTitle(String title) {
        int f = -1;
        for (int i = 0; i < this.inventory.size(); i++) {
            if (title.equals(this.inventory.get(i).getTitle())) {
                f = i;
            }
        }
        return this.inventory.get(f);
    }

    public void addMedia(Media media) {
        this.inventory.add(media); // adds a track to the playList
    }

    public boolean isEmpty() {

        boolean empty = true; // the playList is empty

        if (this.inventory.size() > 0) // if the playList is not empty, empty = true;
        {
            empty = false;
        }

        return empty;
    }

}
