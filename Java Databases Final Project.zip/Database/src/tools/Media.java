package tools;

public class Media {
    private int itemNo;
    private String title;
    private String location;
    private int length;

    public Media(int itemNo, String title, String location, int length) {
        this.itemNo = itemNo;
        this.title = title;
        this.location = location;
        this.length = length;
    }

    public int getItemNo() {
        return this.itemNo;
    }

    public String getTitle() {
        return this.title;
    }

    public String getLocation() {
        return this.location;
    }

    public int getlength() {
        return this.length;
    }

    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public void printAttributes() {
        System.out.println("itemNo: " + this.itemNo);
        System.out.println("title: " + this.title);
        System.out.println("location: " + this.location);
        System.out.println("length: " + this.length);
    }
}
